#include "mazesolver.h"



constexpr unsigned X = -1;

bool isWall(const Pos& pos, const vector<vector<unsigned> > & maze)
{
    return maze[pos.row][pos.col] == X;
}

bool isInRange(const Pos& pos, const vector<vector<unsigned> > & maze)
{
    const unsigned height = maze.size();
    const unsigned width = maze[0].size();
    return pos.row >= 0 && pos.row < height
            && pos.col >= 0 && pos.col < width;
}

namespace
{

    bool recurse(const Pos& curPos, vector< Pos > & solution, unordered_set< Pos > & explored, const Pos& goal, const vector< vector<unsigned> > & maze)
    {

        if ( curPos == goal && maze[curPos.row][curPos.col] == 1 )
        {
            if ( explored.find(curPos) == explored.end() )
            {
                solution.push_back(curPos);
                explored.insert(curPos);
            }
            return true;
        }

        if ( !isWall(curPos, maze) )
        {
            if ( explored.find(curPos) == explored.end() )
            {
                solution.push_back(curPos);
                explored.insert(curPos);

                int r = curPos.row, c = curPos.col;

                if ( r + 1 != maze.size() )
                    if ( recurse(curPos.getBottomNeighbor(), solution, explored, goal, maze) == true )
                        return true;

                if ( c + 1 != maze[0].size() )
                    if ( recurse(curPos.getRightNeighbor(), solution, explored, goal, maze) == true )
                        return true;

                if ( (r - 1) >= 0 )
                    if ( recurse(curPos.getTopNeighbor(), solution, explored, goal, maze) == true )
                        return true;

                if ( (c - 1) >= 0 )
                  if ( recurse(curPos.getLeftNeighbor(), solution, explored, goal, maze) == true )
                        return true;
                



                 solution.pop_back();

            }
        }
        return false;
    }
} // namespace

// Solve maze via DFS (recursive backtracking).

std::vector<Pos> computeMazePath(const std::vector< std::vector<unsigned>> &maze)
{
    // TODO const Pos*
    std::vector<Pos> solution;
    std::unordered_set<Pos> explored;
    const Pos goal(maze.size() - 1, maze[0].size() - 1);

    // Good practice to label your unnamed args with a comment.
    const bool succeeded = recurse(Pos(0, 0), solution, explored, goal, maze);
    if ( !succeeded )
    {
        throw runtime_error("Failed to find a solution.");
    }
    return solution;
}


// Returns the number of cells in the path found by the solver.  

unsigned mazeCost(const std::vector<Pos> & vP)
{
    return vP.size();
}
