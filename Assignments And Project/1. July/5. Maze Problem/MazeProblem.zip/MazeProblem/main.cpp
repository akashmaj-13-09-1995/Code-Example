#include "mazesolver.h"
#include <iostream>

unsigned X = -1;
int main()
{

    std::cout << "Hello World\n";
    std::vector<std::vector<unsigned>> maze1 = {
        {1, X, X, X, X, 1, X, X, 1, X},
        {1, 1, X, 1, X, 1, X, X, 1, X},
        {1, 1, 1, 1, 1, 1, X, X, 1, X},
        {1, X, X, X, X, 1, X, X, 1, X},
        {1, X, X, X, X, 1, X, X, 1, X},
        {1, X, X, X, X, 1, X, X, 1, X},
        {1, X, X, X, X, 1, X, X, 1, X},
        {1, X, X, X, X, 1, X, X, 1, X},
        {1, X, X, X, X, 1, 1, 1, 1, 1},
        {X, X, X, X, X, 1, X, X, 1, 1},
    };
    vector< Pos >  solution=computeMazePath(maze1);
    for(int i=0;i<solution.size();i++)
        cout<<"("<<solution[i].row<<","<<solution[i].col<<")\n";
    return 0;
}