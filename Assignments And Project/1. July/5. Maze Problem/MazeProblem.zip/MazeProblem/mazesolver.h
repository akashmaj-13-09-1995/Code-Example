#ifndef __MAZESOLVER_H
#define __MAZESOLVER_H

#include "Pos.h"
#include <vector>
#include <queue>
#include <string>
#include <unordered_set>
#include <bits/stdc++.h>

using namespace std;


    bool isWall(const Pos& pos, const std::vector< std::vector<unsigned> > & maze);

    bool isInRange(const Pos& pos, const std::vector< std::vector<unsigned> > & maze);

    vector<Pos> computeMazePath(const std::vector< std::vector<unsigned> > & maze);

#endif  /* __MAZESOLVER_H */