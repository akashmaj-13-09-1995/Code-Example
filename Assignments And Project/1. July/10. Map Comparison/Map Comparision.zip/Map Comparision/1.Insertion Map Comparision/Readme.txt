

To run the application,

Step1: go to "terminal" if you are using linux, or "cmd" if you are using windows

Step2: run below command

                   g++ main.cpp pbPlots.cpp  supportLib.cpp -lm


Step3: Now run "./a.out"




Note:
You will get the two plotted graph.
To get the observble result, use smaller value for the "Number of points:" like 1000

And in the plotted graph, x-axis denotes the point and y-axis denotes the time taken
