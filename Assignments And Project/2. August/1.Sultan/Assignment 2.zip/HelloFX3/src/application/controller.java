package application;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;

public class controller {
	float num1,num2,res;
	@FXML
	TextField number1TextFiled;
	
	@FXML
	TextField number2TextFiled;
	
	@FXML
	private TextField resultTextFiled;
	
	@FXML
	Label Xiaojie_Zhu;
	
	public void add() {
		try {
		num1=Integer.parseInt(number1TextFiled.getText());
		num2=Integer.parseInt(number2TextFiled.getText());
		res=num1+num2;
		System.out.print(res);
		
		resultTextFiled.setText(String.valueOf(res));
		}
		catch(Exception e) {
		System.out.println(e);	
		}
		


	}

	public void sub() {
		try {
			num1=Integer.parseInt(number1TextFiled.getText());
			num2=Integer.parseInt(number2TextFiled.getText());
			res=num1-num2;
			System.out.print(res);

			resultTextFiled.setText(String.valueOf(res));
			}
			catch(Exception e) {
			System.out.println(e);	
			}
			
	}
	public void mult() {
		try {
			num1=Integer.parseInt(number1TextFiled.getText());
			num2=Integer.parseInt(number2TextFiled.getText());
			res=num1*num2;
			System.out.print(res);

			resultTextFiled.setText(String.valueOf(res));
			}
			catch(Exception e) {
			System.out.println(e);	
			}
			
	}
	public void div() {
		try {
			num1=Integer.parseInt(number1TextFiled.getText());
			num2=Integer.parseInt(number2TextFiled.getText());
			res=num1/num2;
			System.out.print(res);

			resultTextFiled.setText(String.valueOf(res));
			}
			catch(Exception e) {
			System.out.println(e);	
			}
			
	}
	public void sign() {
		Xiaojie_Zhu.setTextFill(Color.web("red"));
		Xiaojie_Zhu.setText("Sultan");
		

	}
}

